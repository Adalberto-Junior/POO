package P105589.POO2122.POO2122;

public abstract class Activity {
    
    public abstract void setCliente(int ncliente);
    public abstract int getCliente();
    public abstract double getPreco();
    public abstract String toString();
    public abstract boolean equals(Object o);
}
