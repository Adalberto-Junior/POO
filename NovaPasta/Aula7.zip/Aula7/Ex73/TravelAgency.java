package Aula7.Ex73;

public class TravelAgency {
     private String name;
     private String address;
     private Accommodation house[];
     private Car rent[];
     private static int carIndx  = 0;
     private static int houIndex = 0;

    //construtors()
    public TravelAgency(){}
    public TravelAgency(String name, String address, int carLength, int accomLength ){
          this.name = name;
          this.address = address;
          this.rent = new Car[carLength];
          this.house = new Accommodation[accomLength];
     }
    //sets();
    public void setName(String name){this.name = name;}
    public void setAddress(String address){this.address = address;}
    public void setRent(Car x){
          if(carIndx < this.rent.length){
               this.rent[carIndx] = x;
               carIndx++;
          }  
     }
    public void setHouse(Accommodation x){
          if(houIndex < this.house.length){
               this.house[houIndex] = x;
               houIndex++;
          }  
     }
    //gets();
    public String getName(){return this.name;}
    public String getAddress(){return this.address;}
    public Car getRent(){
         Car x = new Car(); 
         for(Car u: this.rent)
            x = u;
         return x;
     }
    public Accommodation getHouse(){
     Accommodation x = new Accommodation();
     for(Accommodation u: this.house)
          x = u;    
     return x;}

    public int getACar(char clas, String egT){
         //Car x = new Car(); // um só carro
         int k = -1;
         for(int i = 0; i < rent.length; i++){
             if(rent[i].getClasse() == clas && rent[i].getEgineType().equals(egT)){
                k = i;
                  break;
             }
         }
         return k;
    }
    public int getAHous(String nom, String cd){  // return indice de um certo alojamento
     
     int k = -1;
     for(int i = 0; i < house.length; i++){
         if(house[i].getName().equals(nom) && house[i].getCode().equals(cd)){
            k = i;
              break;
         }
     }
     return k;
}

    public void rent(int cc, int i){
         rent[i].rent(cc);
    }
    public void deliver(int i){
         rent[i].deliver();
    }
    public void checkIn(int j){
         String cd = house[j].getCode();
         house[j].checkIn(cd);
    }
    public void checkOut(int j){
         String cd = house[j].getCode();
         house[j].checkOut(cd);
    }


    @Override
    public String toString(){
         return "Travel Agency: " + this.name + "; " + "Address: " + this.address + ";";
    }
    @Override
    public boolean equals(Object objt){
        if(this == objt)
          return true;
        if(objt == null)
          return false;
        if(this.getClass() != objt.getClass())
          return false;
        TravelAgency other = (TravelAgency) objt;
        if(this.name == null){
            if(other.name != null)
              return false;
        }else if(!this.name.equals(other.name))
              return false;
        if(this.address == null){
            if(other.address != null)
              return false;
        }else if(!this.address.equals(other.address))
              return false;
        return true;
    }
}
