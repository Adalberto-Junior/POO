package Aula7.E71;

public abstract class Forma {
    protected String cor;
    
    public abstract double area();
    public abstract double perimetro();
    
}
