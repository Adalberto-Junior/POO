package Aula8.Ex2;

public enum VariedadeCarne {
    
    FRANGO, VACA, PORCO, PERU, OUTRA
}
