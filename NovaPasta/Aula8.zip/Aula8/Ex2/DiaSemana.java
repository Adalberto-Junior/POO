package Aula8.Ex2;

public enum DiaSemana {
    Domingo, Segunda, Terca, Quarta, Quinta, Sexta, Sabado
}
